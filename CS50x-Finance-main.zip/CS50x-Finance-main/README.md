# CS50-Finance
🤑 PSET9 of "Harvard CS50's Introduction to Computer Science"


## Demo
![image](https://user-images.githubusercontent.com/92586852/213960254-d1c3dffe-24d1-4139-ae16-004316e6e02d.png)
